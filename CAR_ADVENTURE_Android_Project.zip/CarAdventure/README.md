# CAR ADVENTURE — Android Studio project

Based on the supplied midterm proposal. Includes:
- Main menu with 2D racing and 3D showcase entries
- 2D lane-based racer: touch/keyboard steering, obstacles, score, collision, restart
- Stylized rotating character showcase (placeholder art, not a supplied 3D model)
- Android WebView wrapper, portrait orientation, immersive fullscreen

## Build APK
1. Open this folder in Android Studio (recent version).
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the generated APK location (normally `app/build/outputs/apk/debug/app-debug.apk`).

This workspace did not have Android SDK / Gradle installed, so an APK binary could not be compiled or device-tested here.
